/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package laboop.Lab01;
import javax.swing.JOptionPane;
public class FirstDialog {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Hello World! How are you?");
		System.exit(0);
		
	}

}
